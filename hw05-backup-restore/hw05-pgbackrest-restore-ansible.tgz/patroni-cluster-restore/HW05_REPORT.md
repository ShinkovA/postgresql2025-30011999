# HW05 — Бэкапы и восстановление PostgreSQL (pgBackRest)

## Цель

Настроить надёжное резервное копирование PostgreSQL и проверить восстановление на отдельном узле.

## Стенд

- 3 x etcd
- 3 x PostgreSQL/Patroni
- 1 x HAProxy
- 1 x backup-01 (NFS + pgBackRest repo)
- 1 x restore-01 (standalone PostgreSQL для проверки restore)

## Что было сделано

1. На основном кластере оставлен pgBackRest с архивированием WAL.
2. Репозиторий бэкапов вынесен на отдельную VM `backup-01` и экспортируется по NFS.
3. На Patroni-нодах включены регулярные бэкапы через systemd timers:
   - weekly full
   - daily diff
4. Для проверки восстановления подготовлена отдельная VM `restore-01` без Patroni.
5. `restore-01` монтирует NFS-репозиторий и выполняет `pgbackrest restore` latest backup.
6. После restore поднимается standalone PostgreSQL и выполняются контрольные запросы.

## Команды

### Создание restore-VM

```bash
ansible-playbook -i inventory/hosts.yml playbooks/create_infra_vms.yml \
  -e provision_vms=false \
  -e provision_restore_vm=true
```

### Настройка restore-VM

```bash
ansible-playbook -i inventory/hosts.yml playbooks/configure_restore_node.yml
```

### Восстановление latest backup

```bash
ansible-playbook -i inventory/hosts.yml playbooks/restore_pgbackrest.yml
```

## Проверка бэкапа

На leader:

```bash
sudo -u postgres pgbackrest --stanza=pgcluster info
sudo -u postgres pgbackrest --stanza=pgcluster check
```

## Проверка restore

На `restore-01`:

```bash
sudo systemctl status postgresql-restore
sudo -u postgres psql -p 5432 -c "select pg_is_in_recovery();"
sudo -u postgres psql -p 5432 -d postgres -c "select now();"
```

## Проверка данных

Для отчёта удобно заранее создать тестовую БД `loyalty_wholesale`, таблицу с несколькими строками и сверить после восстановления:

```sql
select count(*) from clients;
select sum(bonus_points) from clients;
select md5(string_agg(client_id || ':' || bonus_points, ',' order by client_id)) from clients;
```

## Что приложить к сдаче

- скрин `pgbackrest info`
- скрин списка Patroni до/после backup
- скрин с `restore-01` после восстановления
- контрольные SQL-запросы до и после restore

## Вывод

Бэкапы выполняются вне основного репозитория данных, WAL архивируются, а восстановление проверяется на отдельной VM. Такой подход снижает риск ложного ощущения защищённости: мы проверяем не только создание backup, но и реальную возможность восстановления.
